from django.apps import AppConfig


class IdcsConfig(AppConfig):
    name = 'idcs'
